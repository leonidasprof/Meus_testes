export type Teacher = {
  id: string
  name: string
  disciplines: string[]
  createdAt: Date
}

export type Resource = {
  id: string
  name: string
  type: "AUDITORIUM" | "LIBRARY" | "COMPUTER_LAB" | "MOBILE_PC" | "MOBILE_PROJECTOR"
  icon: string
}

export type Booking = {
  id: string
  teacherId: string
  resourceId: string
  date: string
  startTime: string
  createdAt: Date
}

