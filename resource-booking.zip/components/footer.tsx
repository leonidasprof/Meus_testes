export function Footer() {
  return (
    <footer className="w-full border-t bg-white py-4">
      <div className="container flex justify-center text-center text-sm text-gray-600">
        <p>© Todos os direitos reservados EREFEM BEG 2025</p>
      </div>
    </footer>
  )
}

