"use server"

import { revalidatePath } from "next/cache"
import { z } from "zod"
import type { Teacher, Booking } from "@/lib/types"

let teachers: Teacher[] = []
let bookings: Booking[] = []

const TeacherSchema = z.object({
  name: z.string().min(1, "Nome é obrigatório"),
  disciplines: z
    .string()
    .min(1, "Disciplina é obrigatória")
    .transform((d) => d.split(",").map((item) => item.trim())),
})

export async function createTeacher(prevState: any, formData: FormData) {
  const validatedFields = TeacherSchema.safeParse({
    name: formData.get("name"),
    disciplines: formData.get("disciplines"),
  })

  if (!validatedFields.success) {
    return { error: validatedFields.error.flatten().fieldErrors }
  }

  const teacher: Teacher = {
    id: Math.random().toString(36).slice(2),
    ...validatedFields.data,
    createdAt: new Date(),
  }

  teachers.push(teacher)
  revalidatePath("/teachers")
  return { success: true, teacher }
}

const BookingSchema = z.object({
  teacherId: z.string().min(1, "Professor é obrigatório"),
  resourceId: z.string().min(1, "Recurso é obrigatório"),
  date: z.string().min(1, "Data é obrigatória"),
  startTime: z.string().min(1, "Horário de início é obrigatório"),
})

export async function createBooking(prevState: any, formData: FormData) {
  const validatedFields = BookingSchema.safeParse({
    teacherId: formData.get('teacherId'),
    resourceId: formData.get('resourceId'),
    date: formData.get('date'),
    startTime: formData.get('startTime'),
  })

  if (!validatedFields.success) {
    return { error: validatedFields.error.flatten().fieldErrors }
  }

  const { teacherId, resourceId, date, startTime } = validatedFields.data

  // Check for conflicts and get teacher info
  const existingBooking = bookings.find(booking => 
    booking.resourceId === resourceId &&
    booking.date === date &&
    booking.startTime === startTime
  )

  if (existingBooking) {
    const teacher = teachers.find(t => t.id === existingBooking.teacherId)
    return { 
      error: { 
        conflict: `Horário já reservado pelo professor ${teacher?.name}` 
      } 
    }
  }

  const booking: Booking = {
    id: Math.random().toString(36).slice(2),
    teacherId,
    resourceId,
    date,
    startTime,
    createdAt: new Date()
  }

  bookings.push(booking)
  revalidatePath(`/resources/${resourceId}/schedule`)
  return { success: true, booking }
}

export async function getTeachers() {
  return teachers
}

export async function getBookings(resourceId?: string) {
  let filteredBookings = bookings
  if (resourceId) {
    filteredBookings = bookings.filter((b) => b.resourceId === resourceId)
  }

  // Add teacher information to bookings
  return Promise.all(
    filteredBookings.map(async (booking) => {
      const teacher = teachers.find((t) => t.id === booking.teacherId)
      return {
        ...booking,
        teacherName: teacher?.name,
      }
    }),
  )
}

