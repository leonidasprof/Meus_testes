"use client"

import { useState, useEffect, useRef } from "react"
import { useFormState } from "react-dom"
import { useRouter } from "next/navigation"
import { createBooking, getTeachers } from "@/app/actions"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { CalendarIcon, ArrowLeft } from 'lucide-react'
import Link from "next/link"
import { ptBR } from 'date-fns/locale'
import type { Teacher } from "@/lib/types"

const timeSlots = [
  "07:00", "07:50", "08:40", "09:30", "10:40",
  "11:30", "12:50", "14:00", "14:50", "15:40",
  "16:50", "17:40", "19:10", "20:00"
]

const initialState = {
  error: null,
  success: false,
}

export default function ResourceBooking({
  params,
}: {
  params: { type: string }
}) {
  const router = useRouter()
  const [date, setDate] = useState<Date>()
  const [teachers, setTeachers] = useState<Teacher[]>([])
  const [state, formAction] = useFormState(createBooking, initialState)
  const dateInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    getTeachers().then(setTeachers)
  }, [])

  useEffect(() => {
    if (state?.success) {
      router.push(`/resources/${params.type}/schedule`)
    }
  }, [state, router, params.type])

  const handleDateSelect = (newDate: Date | undefined) => {
    setDate(newDate)
    if (newDate && dateInputRef.current) {
      dateInputRef.current.value = newDate.toISOString().split('T')[0]
    }
  }

  return (
    <Card className="w-full max-w-md">
      <CardHeader className="flex flex-row items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" onClick={() => router.back()}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <CardTitle className="capitalize">{params.type.replace("-", " ")}</CardTitle>
        </div>
        <Link href={`/resources/${params.type}/schedule`}>
          <Button className="bg-blue-500 hover:bg-blue-600 text-white">
            Agendamentos
            <CalendarIcon className="ml-2 h-4 w-4" />
          </Button>
        </Link>
      </CardHeader>
      <CardContent>
        <form action={formAction} className="space-y-4">
          <input type="hidden" name="resourceId" value={params.type} />
          <div className="space-y-2">
            <Label htmlFor="teacherId">Professor</Label>
            <Select name="teacherId" required>
              <SelectTrigger id="teacherId">
                <SelectValue placeholder="Selecione o professor" />
              </SelectTrigger>
              <SelectContent>
                {teachers.map((teacher) => (
                  <SelectItem key={teacher.id} value={teacher.id}>
                    {teacher.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {state?.error?.teacherId && <p className="text-sm text-red-500">{state.error.teacherId}</p>}
          </div>
          <div className="space-y-2">
            <Label>Dia</Label>
            <div className="flex justify-center">
              <Calendar
                mode="single"
                selected={date}
                onSelect={handleDateSelect}
                className="rounded-md border"
                locale={ptBR}
                weekStartsOn={0}
                weekdayFormat="EEEEE"
              />
            </div>
            <input type="hidden" name="date" ref={dateInputRef} id="date-input" />
            {state?.error?.date && <p className="text-sm text-red-500">{state.error.date}</p>}
          </div>
          <div className="space-y-2">
            <Label htmlFor="startTime">Horário</Label>
            <Select name="startTime" required>
              <SelectTrigger id="startTime">
                <SelectValue placeholder="Selecione o horário" />
              </SelectTrigger>
              <SelectContent>
                {timeSlots.map((time) => (
                  <SelectItem key={time} value={time}>
                    {time}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {state?.error?.startTime && <p className="text-sm text-red-500">{state.error.startTime}</p>}
          </div>
          {state?.error?.conflict && <p className="text-sm text-red-500">{state.error.conflict}</p>}
          <Button type="submit" className="w-full">
            Reservar
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}

