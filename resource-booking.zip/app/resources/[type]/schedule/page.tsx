import { getBookings } from '@/app/actions'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { format } from 'date-fns'
import { ptBR } from 'date-fns/locale'
import { ArrowLeft } from 'lucide-react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'

export default async function Schedule({ 
  params 
}: { 
  params: { type: string } 
}) {
  const bookings = await getBookings(params.type)

  return (
    <div className="w-full max-w-2xl space-y-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href={`/resources/${params.type}`}>
              <Button variant="ghost">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <CardTitle className="capitalize">
              Agendamentos - {params.type.replace('-', ' ')}
            </CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="divide-y">
            {bookings.map((booking) => (
              <div key={booking.id} className="py-4">
                <p className="font-medium">
                  Professor: {booking.teacherName}
                </p>
                <p className="text-sm text-gray-600">
                  Dia: {format(new Date(booking.date), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
                </p>
                <p className="text-sm text-gray-600">
                  Horário: {booking.startTime}
                </p>
              </div>
            ))}
            {bookings.length === 0 && (
              <p className="py-4 text-center text-gray-500">
                Nenhum agendamento encontrado
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

