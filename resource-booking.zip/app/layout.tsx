import { Inter } from "next/font/google"
import "./globals.css"
import { Footer } from "@/components/footer"
import { Home } from "lucide-react"
import Link from "next/link"
import type React from "react"
import { usePathname } from "next/navigation"

const inter = Inter({ subsets: ["latin"] })

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const pathname = usePathname()
  const isHomePage = pathname === "/"

  return (
    <html lang="pt-BR">
      <body className={`${inter.className} flex min-h-screen flex-col`}>
        <header className="sticky top-0 z-50 w-full border-b bg-white">
          <div className="container flex h-16 items-center justify-between px-4">
            {!isHomePage && (
              <Link href="/" className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                <Home className="h-6 w-6" />
              </Link>
            )}
            <div className="flex justify-center flex-1">
              <img
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ebeg_logo-uqQWfmgaaAb7J6KvAVQBt1gasVzK25.png"
                alt="EREFEM BEG 2025 Logo"
                className="h-12 w-auto"
              />
            </div>
            {!isHomePage && <div className="w-10" />} {/* Espaçador para manter o logo centralizado */}
          </div>
        </header>
        <main className="flex-1 container mx-auto flex items-center justify-center p-4">{children}</main>
        <Footer />
      </body>
    </html>
  )
}

