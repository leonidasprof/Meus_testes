"use client"

import { useEffect } from "react"
import { useFormState } from "react-dom"
import { useRouter } from "next/navigation"
import { createTeacher } from "@/app/actions"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

const initialState = {
  error: null,
  success: false,
}

export default function NewTeacher() {
  const router = useRouter()
  const [state, formAction] = useFormState(createTeacher, initialState)

  useEffect(() => {
    if (state?.success) {
      router.push("/")
    }
  }, [state, router])

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle>Cadastro de Professores</CardTitle>
      </CardHeader>
      <CardContent>
        <form action={formAction} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Nome</Label>
            <Input id="name" name="name" required />
            {state?.error?.name && <p className="text-sm text-red-500">{state.error.name}</p>}
          </div>
          <div className="space-y-2">
            <Label htmlFor="disciplines">Disciplina(s)</Label>
            <Input
              id="disciplines"
              name="disciplines"
              placeholder="Separe múltiplas disciplinas por vírgula"
              required
            />
            {state?.error?.disciplines && <p className="text-sm text-red-500">{state.error.disciplines}</p>}
          </div>
          <Button type="submit" className="w-full">
            Cadastrar
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}

