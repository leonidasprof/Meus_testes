import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Users, Mic2, BookOpen, Monitor, Laptop, Projector } from "lucide-react"

const resources = [
  {
    id: "teachers",
    name: "Cadastro Professores",
    color: "bg-green-500 hover:bg-green-600",
    href: "/teachers/new",
    icon: Users,
  },
  {
    id: "auditorium",
    name: "Auditório",
    color: "bg-blue-900 hover:bg-blue-800",
    href: "/resources/auditorium",
    icon: Mic2,
  },
  {
    id: "library",
    name: "Biblioteca",
    color: "bg-blue-900 hover:bg-blue-800",
    href: "/resources/library",
    icon: BookOpen,
  },
  {
    id: "computers",
    name: "Informática",
    color: "bg-blue-900 hover:bg-blue-800",
    href: "/resources/computers",
    icon: Monitor,
  },
  {
    id: "mobile-pcs",
    name: "PCs Móvel",
    color: "bg-blue-900 hover:bg-blue-800",
    href: "/resources/mobile-pcs",
    icon: Laptop,
  },
  {
    id: "projector",
    name: "Projetor Móvel",
    color: "bg-blue-900 hover:bg-blue-800",
    href: "/resources/projector",
    icon: Projector,
  },
]

export default function Home() {
  return (
    <div className="w-full max-w-md space-y-4">
      <h1 className="text-2xl font-bold text-center text-blue-900">Sistema de Reserva</h1>
      <div className="grid gap-4">
        {resources.map((resource) => (
          <Link key={resource.id} href={resource.href}>
            <Card className="transition-transform hover:scale-105">
              <CardContent className="flex items-center p-4 gap-4">
                <div
                  className={`w-12 h-12 ${resource.color} rounded-lg flex items-center justify-center text-white transition-colors`}
                >
                  {resource.icon && <resource.icon size={24} />}
                </div>
                <span className="text-lg font-medium text-blue-900">{resource.name}</span>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  )
}

